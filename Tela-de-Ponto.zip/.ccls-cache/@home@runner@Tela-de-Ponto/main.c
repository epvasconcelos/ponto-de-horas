#include <stdio.h>
int main(void) {
  int he,me,hs,ms,h;
  
  printf("Deseja inserir horário de entrada(1) ou saida(2)?\n");
  scanf("%d",&h);
  switch(h){
  
    case 1:printf("Insira a hora de entrada:\n");
  scanf("%d",&he);
  printf("Insira o minuto de entrada:\n");
  scanf("%d",&me);
  printf("Horario de entrada %d:%d",he,me);
  break;
    case 2:printf("Insira a hora de saida:\n");
  scanf("%d",&he);
  printf("Insira o minuto de saida:\n");
  scanf("%d",&me);
  printf("Horario de saida %d:%d",he,me);
      break;
      default:printf("Operação invalida");}
  return 0;
}